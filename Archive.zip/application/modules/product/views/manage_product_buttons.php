<div class="col-md-12">
    <a href="<?php echo base_url();?>Product/addCategory"><button class="btn btn-success">Add Category</button></a>
    <a href="<?php echo base_url();?>Product/addSubCategory"><button class="btn btn-success">Add Subcategory</button></a>
    <a href="<?php echo base_url();?>Product/addProduct"><button class="btn btn-success">Add Product</button></a>
</div></br>