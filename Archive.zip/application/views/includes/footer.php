    
    <script src="<?php base_url();?>assets/js/vendors.min.js"></script>
    <script src="<?php base_url();?>assets/js/LivIconsEvo.tools.js"></script>
    <script src="<?php base_url();?>assets/js/LivIconsEvo.defaults.js"></script>
    <script src="<?php base_url();?>assets/js/LivIconsEvo.min.js"></script>
    <script src="<?php base_url();?>assets/js/vertical-menu-light.js"></script>
    <script src="<?php base_url();?>assets/js/app-menu.js"></script>
    <script src="<?php base_url();?>assets/js/app.js"></script>
    <script src="<?php base_url();?>assets/js/components.js"></script>
    <script src="<?php base_url();?>assets/js/footer.js"></script>   
  </body>
</html>